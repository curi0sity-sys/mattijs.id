function toggleTOC() {
    const toc = document.querySelector('.toc');
    toc.classList.toggle('active');
}

function hideTOCOnLinkClick(event) {
    const toc = document.querySelector('.toc');
    if (event.target.tagName.toLowerCase() === 'a') {
        toc.classList.remove('active');
    }
}

document.addEventListener("DOMContentLoaded", function () {
    const tocContainer = document.getElementById("table-of-contents");
    const tocBlock = document.querySelector('.toc');
    if (!tocContainer || !tocBlock) return;

    const headings = document.querySelectorAll("article h1, article h2, article h3, article h4");
    let hasValidHeading = false;

    const tocList = document.createElement("ul");
    headings.forEach(heading => {
        if (!heading.id) return; // Ignore headings without an ID

        hasValidHeading = true; // At least one heading has an ID

        const listItem = document.createElement("li");
        const link = document.createElement("a");
        link.href = `#${heading.id}`;
        link.textContent = heading.textContent;

        // Add different classes based on heading type
        if (heading.tagName.toLowerCase() === 'h1') {
            link.classList.add('toc-link-h1');
        } else if (heading.tagName.toLowerCase() === 'h2') {
            link.classList.add('toc-link-h2');
        } else if (heading.tagName.toLowerCase() === 'h3') {
            link.classList.add('toc-link-h3');
        } else if (heading.tagName.toLowerCase() === 'h4') {
            link.classList.add('toc-link-h4');
        }

        link.addEventListener("click", function (event) {
            event.preventDefault();
            const targetHeading = document.getElementById(heading.id);
            const tocElement = document.querySelector('.toc');
            
            // Calculate the offset needed to account for sticky TOC
            const tocHeight = tocElement ? tocElement.offsetHeight : 0;
            const offset = tocHeight + 16; // Add 16px padding for better spacing
            
            // Get the target element's position relative to the document
            const targetPosition = targetHeading.getBoundingClientRect().top + window.pageYOffset;
            
            // Scroll to the position minus the offset
            window.scrollTo({
                top: targetPosition - offset,
                behavior: "smooth"
            });
            
            hideTOCOnLinkClick(event); // Hide the TOC when a link is clicked
        });
        listItem.appendChild(link);
        tocList.appendChild(listItem);
    });

    if (!hasValidHeading) {
        tocBlock.style.display = 'none';
        return;
    }

    tocContainer.appendChild(tocList);
});