const themeSwitcher = document.getElementById("theme-switcher");
let currentTheme = localStorage.getItem("theme");

const systemPrefersDark = window.matchMedia(
	"(prefers-color-scheme: dark)"
).matches;

if (currentTheme) {
	document.documentElement.setAttribute("data-theme", currentTheme);
} else if (systemPrefersDark) {
	currentTheme = "dark";
	document.documentElement.setAttribute("data-theme", "dark");
	themeSwitcher.checked = true;
} else {
	currentTheme = "light";
	document.documentElement.setAttribute("data-theme", "light");
	themeSwitcher.checked = false;
}

if (currentTheme === "dark") {
	themeSwitcher.checked = true;
} else {
	themeSwitcher.textContent = "Toggle Dark Theme";
}

themeSwitcher.addEventListener("click", () => {
	let theme = "light";
	if (
		!document.documentElement.getAttribute("data-theme") ||
		document.documentElement.getAttribute("data-theme") === "light"
	) {
		theme = "dark";
	}
	document.documentElement.setAttribute("data-theme", theme);
	localStorage.setItem("theme", theme);
});