export default {
  name: 'Navigation',
  data() {
    return {
      timeout: null,
      debounce: 500
    }
  },
  computed: {
    files() {
      return this.$store.getters.fileOptions
    },
    active() {
      return this.$store.getters.selectedFile
    }
  },
  methods: {
    loadFile(file) {
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        this.$store.dispatch('loadFile', file)
      }, this.debounce)
    }
  }
}
