<template>
    <nav>
        <ul>
            <li v-for="file in files" @click="loadFile(file)" :key="file" :class="{ active : file === active }">{{ file }}</li>
        </ul>
    <img src='../../assets/beta.png' alt='' title='' width='200px' height='203px' />
    </nav>
</template>

<script src="./Navigation.js" />
<style src="./Navigation.scss" lang="scss" />
