<template>
  <div id="app" class="container">
    <Navigation />
    <Editor />
  </div>
</template>

<script src="./App.js" />
<style src="./App.scss" lang="scss" />
