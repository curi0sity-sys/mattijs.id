import Navigation from '../Navigation/Navigation.vue'
import Editor from '../Editor/Editor.vue'

export default {
  name: 'App',
  components: { Navigation, Editor },
  mounted () {
    this.$store.dispatch('loadFile')
  }
}
