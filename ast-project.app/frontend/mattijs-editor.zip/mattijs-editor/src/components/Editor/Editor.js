export default {
  name: 'Editor',
  components: {
    editor: require('vue2-ace-editor')
  },
  data() {
    return {
      timeout: null,
      debounce: 200
    }
  },
  computed: {
    editorContent: {
      get: function () { return this.$store.getters.editorContent },
      set: function(value) {
        clearTimeout(this.timeout)
        this.timeout = setTimeout(() => {
          this.$store.dispatch('setEditorContent', value)
        }, this.debounce)
      }
    },
    jvm () { return this.$store.getters.jvm },
    output () { return this.$store.getters.programOutput },
    xref () { return this.$store.getters.xref }
  },
  methods: {
    editorInit: function (editor, editable = false) {
      require('brace/ext/language_tools') // language extension prerequsite...
      require('brace/mode/pascal')
      require('brace/mode/java')
      require('brace/mode/json')
      require('brace/theme/dracula')
      editable ? editor.setReadOnly(false) : editor.setReadOnly(true)
      editor.setShowPrintMargin(false)
    }
  }
}
