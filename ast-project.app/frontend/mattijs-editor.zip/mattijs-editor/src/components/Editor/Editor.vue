<template>
    <div class="editor_container">
        <div class="column editor">
            <editor v-model="editorContent" @init="editorInit($event, true)" lang="pascal" theme="dracula"  />
        </div>
        <div class="column editor">
            <editor :value="jvm" @init="editorInit($event)" lang="java" theme="dracula" />
        </div>
        <div class="column editor">
            <editor :value="output" @init="editorInit($event)" lang="java" theme="dracula" />
        </div>
        <div class="column editor">
            <editor :value="xref" @init="editorInit($event)" lang="json" theme="dracula"  />
        </div>
    </div>
</template>

<script src="./Editor.js" />
<style scoped src="./Editor.scss" lang="scss" />
