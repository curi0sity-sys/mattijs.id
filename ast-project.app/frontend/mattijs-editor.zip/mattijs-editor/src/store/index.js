import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

const state = {
  fileOptions: [
    'Example1.pas',
    'Example2.pas',
    'Example3.pas',
    'Example4.pas',
    'Example5.pas',
    'Example6.pas',
    'Example7.pas'
  ],
  selectedFile: 'Example1.pas',
  editorContent: '',
  jvm: '',
  programOutput: '',
  xref: '',
  isXrefEnabled: true
}

const getters = {
  fileOptions: state => {
    return state.fileOptions
  },
  editorContent: state => {
    return state.editorContent ? state.editorContent : ''
  },
  jvm: state => {
    return state.jvm ? state.jvm : ''
  },
  programOutput: state => {
    return state.programOutput ? state.programOutput : ''
  },
  xref: state => {
    var json = state.xref ? JSON.parse(state.xref) : ''
    return json ? JSON.stringify(json, null, 2) : ''
  },
  selectedFile: state => {
    return state.selectedFile
  }
}

const actions = {
  loadFile({ commit, state, dispatch }, file = state.selectedFile) {
    commit('setSelectedFile', file)
    dispatch('fetchEditorContent')
  },
  setEditorContent({ commit, dispatch }, content) {
    if (content) {
      commit('setEditorContent', content)
      dispatch('fetchCompiled')
      if (state.isXrefEnabled) dispatch('fetchXref')
    }
  },
  fetchEditorContent({ commit, state }) {
    axios.get(`https://mattijs.sh/rest/show/${state.selectedFile}`)
      .then(response => { commit('setEditorContent', response.data.state) })
      .catch(error => { console.log(error) })
  },
  fetchCompiled({ commit, state }) {
    axios.post('https://mattijs.sh/rest/compile/alloutput', { source: state.editorContent })
      .then(response => { commit('setProgramOutput', response.data) })
      .catch(error => { console.log(error) })
  },
  fetchXref({ commit, state }) {
    axios.post('https://mattijs.sh/rest/xreference', { source: state.editorContent })
      .then(response => { commit('setXref', response.data.state) })
      .catch(error => { console.log(error) })
  }
}

const mutations = {
  setSelectedFile(state, file) {
    state.selectedFile = file
  },
  setEditorContent(state, content) {
    state.editorContent = content
  },
  setProgramOutput(state, data) {
    state.jvm = data.jvm
    state.programOutput = data.programOutput
  },
  setXref(state, data) {
    state.xref = data
  }
}

export default new Vuex.Store({
  state,
  getters,
  actions,
  mutations
})
