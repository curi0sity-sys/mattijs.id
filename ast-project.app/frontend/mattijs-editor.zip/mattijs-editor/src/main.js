import Vue from 'vue'
import Vuex from 'vuex'
import store from './store/index'
import App from './components/App/App.vue'
import 'normalize-scss'

Vue.config.productionTip = false
Vue.use(Vuex)

new Vue({
  render: h => h(App),
  store: store
}).$mount('#app')
